/**
 * These are the predefined product categories that are available to the user.
 *
 * @author Frikk O. Larsen
 * @version 1.0.0
 */
public enum Categories {
  FLOOR,
  WINDOWS,
  DOORS,
  LUMBER;

  /**
   * Transform a given integer into an enum.
   *
   * @param x The integer to transform
   * @return An enum
   */
  public static Categories fromInteger(int x) {
    try {
      return Categories.values()[x - 1];
    } catch (Exception e) {
      System.out.println(e);
      return Categories.FLOOR;
    }
  }
}
