import java.util.Arrays;

/**
 * This class represents a single item. It is managed by the warehouse registry

 * @author Frikk O. Larsen
 * @version 1.0.0
 */
public class Item {
  private final String number;
  private String description;
  private int price;
  private final String brand;
  private final float weight;
  private final float length;
  private final float height;
  private String color;
  private int count;
  private final Categories category;
  private float discount = 0;

  /**
   * Create an item that will be added to the warehouse registry.

   * @param number Item number
   * @param description Item description
   * @param price Item price
   * @param brand Item brand, e.g. Hugo Boss, Gucci etc.
   * @param weight Item weight in kg
   * @param length Item length in cm
   * @param height Item height in cm
   * @param color Item color
   * @param count Items in stock
   * @param category Category of item
   * @throws IllegalArgumentException If one of the parameters are invalid
   */
  public Item(String number, String description, int price, String brand,
              float weight, float length, float height, String color,
              int count, int category, float discountPercentage) throws IllegalArgumentException {

    //Check the parameters given in the constructor
    if (number.trim().equals("")) {
      throw new IllegalArgumentException("Item number must be defined");
    }

    if (description.trim().equals("")) {
      throw new IllegalArgumentException("Item description must be defined");
    }

    if (price < 0) {
      throw new IllegalArgumentException("Item price must be greater than zero");
    }

    if (brand.trim().equals("")) {
      throw new IllegalArgumentException("Item brand must be defined");
    }

    if (weight <= 0) {
      throw new IllegalArgumentException("Item weight must be greater than zero");
    }

    if (length <= 0) {
      throw new IllegalArgumentException("Item length must be greater than zero");
    }

    if (height <= 0) {
      throw new IllegalArgumentException("Item height must be greater than zero");
    }

    if (color.trim().equals("")) {
      throw new IllegalArgumentException("Item color must be defined");
    }

    if (count < 0) {
      throw new IllegalArgumentException("There cannot be fewer than zero items in stock");
    }

    if (category < 1 || category > 4) {
      throw new IllegalArgumentException("The given category number is not valid");
    }

    if (discountPercentage < 0) {
      throw new IllegalArgumentException("The discount percentage cannot be less than 0");
    }

    //Set parameter values
    this.number = number;
    this.description = description;
    this.price = price;
    this.brand = brand;
    this.weight = weight;
    this.length = length;
    this.height = height;
    this.color = color;
    this.count = count;
    this.category = Categories.fromInteger(category);
    this.discount = discountPercentage;
  }

  /**
   *  Creates a deeply cloned instance of this object.
   *
   * @return The deeply cloned Item object
   */
  public Item cloneObject() {
    Item item = this;
    System.out.println(item.getCategory().ordinal());
    return new Item(item.getNumber(), item.getDescription(), item.getPrice(), item.getBrand(),
            item.getWeight(), item.getLength(), item.getHeight(), item.getColor(), item.getCount(),
            item.getCategory().ordinal() + 1, item.getDiscountPercentage());
  }

  //Getter methods

  /**
   * Get the item number.
   *
   * @return Item number
   */
  public String getNumber() {
    return this.number;
  }

  /**
   * Get the item description.
   *
   * @return The item description
   */
  public String getDescription() {
    return this.description;
  }

  /**
   * Get the item price.
   *
   * @return The item price
   */
  public int getPrice() {
    return this.price;
  }

  /**
   * Get the item brand.
   *
   * @return The item brand
   */
  public String getBrand() {
    return this.brand;
  }

  /**
   * Get the item weight.
   *
   * @return The item weight
   */
  public float getWeight() {
    return this.weight;
  }

  /**
   * Get the item length.
   *
   * @return The item length
   */
  public float getLength() {
    return this.length;
  }

  /**
   * Get the item height.
   *
   * @return The item height
   */
  public float getHeight() {
    return this.height;
  }

  /**
   * Get the item color.
   *
   * @return The item color
   */
  public String getColor() {
    return this.color;
  }

  /**
   * Get the current amount of this item.
   *
   * @return The stock of the item
   */
  public int getCount() {
    return this.count;
  }

  /**
   * Get the category of this item. It is a number
   * ranging from 1 to 4.
   *
   * @return The category of the item
   */
  public Categories getCategory() {
    return this.category;
  }

  /**
   * Calculates and returns the discounted item price.
   *
   * @return The discounted price
   */
  public float getDiscountedPrice() {
    return this.price - this.price * this.discount / 100;
  }

  /**
   * Returns the discount percentage.
   *
   * @return Discount percentage
   */
  public float getDiscountPercentage() {
    return this.discount;
  }


  //Setter methods

  /**
   * Sets a new count for the item.
   *
   * @param count The new item count
   */
  public void setCount(int count) {
    if (count < 0) {
      throw new IllegalArgumentException("The item count cannot be less than zero");
    }

    this.count = count;
  }

  /**
   * Sets a new discount percentage for the item.
   *
   * @param discount The new discount percentage
   */
  public void setDiscountPercentage(float discount) {
    if (discount < 0) {
      throw new IllegalArgumentException("The item discount cannot be less than zero");
    }

    this.discount = discount;
  }

  /**
   * Sets the description of the item.
   *
   * @param description The new description of the item
   */
  public void setDescription(String description) {
    if (description.trim().length() == 0) {
      throw new IllegalArgumentException("The item description cannot be an empty string");
    }

    this.description = description;
  }

  /**
   * Sets a new item price.
   *
   * @param price The new price
   */
  public void setPrice(int price) {
    if (price < 0) {
      throw new IllegalArgumentException("The item price cannot be less than zero");
    }

    this.price = price;
  }

  /**
   * Create a human-readable, printable version of the class.

   * @return A human-readable string
   */
  @Override
  public String toString() {
    return "Number: " + this.number + ", Description: " + this.description + ", Price: "
            + this.price + ", Brand: " + this.brand + ", Weight: " + this.weight + "kg, Length: "
            + this.length + "m, Height: " + this.height + "m, Color: " + this.color + ", Count: "
            + this.count + ", Category: " + this.category + ", Discount: " + this.discount
            + "%, Discounted price: " + this.getDiscountedPrice();
  }

  /**
   *  Overrides the default equals method.
   *
   * @param o Object to compare
   * @return True if the same
   */
  @Override
  public boolean equals(Object o) {
    if (this.getClass() != o.getClass()) {
      return false;
    }
    if (this == o) {
      return true;
    }

    // Compare the two Item numbers
    return this.getNumber().toLowerCase().equals(((Item) o).getNumber().toLowerCase());
  }
}