import java.util.ArrayList;
import java.util.List;
import me.xdrop.fuzzywuzzy.FuzzySearch;
import me.xdrop.fuzzywuzzy.model.ExtractedResult;


/**
 * The item registry class manages all the item classes.
 * Because we are having composition structure, every item
 * class will be added to the registry through this class.
 *
 * @author Frikk O. Larsen
 * @version 1.0.0
 */
public class ItemRegistry {
  private final ArrayList<Item> items = new ArrayList<Item>();
  private final String name;

  /**
   * Creates an item registry with the given attributes.
   *
   */
  public ItemRegistry(String name) throws IllegalArgumentException {

    if (name.trim().equals("")) {
      throw new IllegalArgumentException("The name must be defined");
    }

    this.name = name;
  }

  /**
   * Finds a given item in the items list. It does not return a deep copy.
   *
   * @param number The number of the item to search for
   * @return The item matching the given criteria
   */
  private Item searchForItem(String number) {
    Item[] items = this.items.stream()
            .filter(x -> x.getNumber().toLowerCase().equals(number.toLowerCase()))
            .toList()
            .toArray(new Item[0]);

    if (items.length > 0) {
      return items[0];
    }

    return null;
  }

  /**
   * Prints all the stored items from the item registry.
   *
   * @return A list of all the items
   */
  public ArrayList<Item> getAllItems() {
    // Create a deep copy of every item entry
    final ArrayList<Item> itemList = new ArrayList<Item>();
    for (Item entry : this.items) {
      itemList.add(entry.cloneObject());
    }

    // Return the deeply copied list
    return itemList;
  }

  /**
   * Attempts to find an Item that matches the given item number
   * and/or description. The description is matched using fuzzy search
   *
   * @param number The item number
   * @param description The item description
   * @return The item matching the given criteria. Defaults to null if not found.
   */
  public Item findItem(String number, String description) {
    // Firstly, search through the objects, attempting to match the description
    // if description is defined
    if (description != null) {
      // Generate a string only ArrayList from the items in the registry
      final ArrayList<String> strings = new ArrayList<String>(this.items.size());
      for (Item item : this.items) {
        strings.add(item.getDescription());
      }


      // Use FuzzyWuzzy to search the array
      List<ExtractedResult> results = FuzzySearch.extractSorted(description, strings, 40);

      // Return a deep copy of the best matching element if the item number
      // argument is not defined
      if (number == null) {
        // Return null if no items matches the given description
        if (results.size() == 0) {
          return null;
        }

        // Return a deep copy of the Item matching the given description
        return this.items.get(results.get(0).getIndex()).cloneObject();
      }

      // Sort through the items using arraylist streams
      ExtractedResult[] numSearchRes = results.stream()
              .filter(x -> this.items.get(x.getIndex()).getNumber()
                      .toLowerCase().equals(number.toLowerCase()))
              .toList()
              .toArray(new ExtractedResult[0]);

      // Return null if no items with the given number and description were found
      if (numSearchRes.length == 0) {
        return null;
      }

      // Return a deep copy of the item matching both the given number and description
      return this.items.get(numSearchRes[0].getIndex()).cloneObject();
    }

    // Search for a given item number instead
    Item[] result = this.items.stream()
            .filter(x -> x.getNumber().toLowerCase().equals(number.toLowerCase()))
            .toList()
            .toArray(new Item[0]);

    // Return the matching item
    if (result.length > 0) {
      return result[0].cloneObject();
    }

    // Return null if the result array is empty
    return null;
  }

  /**
   *  Add an Item to the item registry. If the item already exists, null will
   *  be returned.
   *
   * @param number Item number
   * @param description Item description
   * @param price Item price
   * @param brand Item brand, e.g. Hugo Boss, Gucci etc.
   * @param weight Item weight in kg
   * @param length Item length in cm
   * @param height Item height in cm
   * @param color Item color
   * @param count Items in stock
   * @param category Category of item
   * @return The newly created item
   */
  public Item addItem(String number, String description, int price, String brand,
                      float weight, float length, float height, String color,
                      int count, int category, float discountPercentage) throws IllegalArgumentException {

    // Create the item object
    final Item item = new Item(number, description, price, brand, weight,
            length, height, color, count, category, discountPercentage);

    // Check if the item already exists in the item list
    if (this.items.contains(item)) {
      return null;
    }

    // Add the newly created item to the item list
    this.items.add(item);

    return item;
  }

  /**
   * Increases the stock of a given item by the specified amount.
   *
   * @param count The amount to increase the stock by
   * @param number The item number belonging to the item
   * @return The updated stock number of the given item
   * @throws IllegalArgumentException If the item is not found
   */
  public int changeItemStock(int count, String number)
          throws IllegalArgumentException {
    // Find the item with the given item number
    final Item item = this.searchForItem(number);
    if (item == null) {
      throw new IllegalArgumentException("There is no item matching the given criteria");
    }

    // Get the old item count
    int oldCount = item.getCount();

    //Set the new count, incrementing by the given amount
    item.setCount(oldCount + count);

    return item.getCount();
  }

  /**
   * Deletes an item from the item registry.
   *
   * @param number The item number to search for
   */
  public boolean deleteItem(String number) {
    // Find the specified item
    Item item = this.searchForItem(number);

    // Return false if not found
    if (item == null) {
      return false;
    }

    // Remove it from the items list
    this.items.remove(item);

    return true;
  }

  /**
   * Change the discount attribute of a specified item.
   *
   * @param discount The discount percentage
   * @param number The item number to search for
   */
  public void changeItemDiscount(float discount, String number)
                                    throws IllegalArgumentException {

    //Find the item
    Item item = this.searchForItem(number);

    if (item == null) {
      throw new IllegalArgumentException("There is no item matching the given criteria");
    }

    item.setDiscountPercentage(discount);

    System.out.println(this.findItem("1A", null));
  }

  /**
   * Change the price attribute of a specified item.
   *
   * @param price The new price
   * @param number The item number
   * @throws IllegalArgumentException If the item is not found
   */
  public void changeItemPrice(int price, String number)
          throws IllegalArgumentException {

    //Find the item
    Item item = this.searchForItem(number);

    if (item == null) {
      throw new IllegalArgumentException("There is no item matching the given criteria");
    }

    item.setPrice(price);
  }

  /**
   * Change the description attribute of a specified item.
   *
   * @param description The new description
   * @param number The item number
   * @throws IllegalArgumentException If the description is invalid, or no items are found
   */
  public void changeItemDescription(String description, String number)
          throws IllegalArgumentException {

    //Find the item
    Item item = this.searchForItem(number);

    if (item == null) {
      throw new IllegalArgumentException("There is no item matching the given criteria");
    }

    // Check for description validity
    if (description.trim().equals("")) {
      throw new IllegalArgumentException("The description is not valid");
    }

    item.setDescription(description);
  }
  
}
