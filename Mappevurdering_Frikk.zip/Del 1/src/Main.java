/**
 * This class is not yet defined to anything.
 */
public class Main {
  /**
   * The main program code.
   *
   * @param args Miscellaneous arguments
   */
  public static void main(String[] args) {
    final int floorLaminates = 1;
    final int windows = 2;
    final int doors = 3;
    final int lumber = 4;

    ItemRegistry registry = new ItemRegistry("Yes");
    try {
      registry.addItem("1A", "Floor tiles", 200,
            "Hunton", 3, 100, 100, "brown", 20, floorLaminates, 0f);
    } catch (IllegalArgumentException e) {
      System.out.println(e);
    }

    try {
      System.out.println(registry.getAllItems());
    } catch (IllegalArgumentException e) {
      System.out.println(e);
    }

    registry.deleteItem("1A");
    System.out.println(registry.getAllItems());
  }
}