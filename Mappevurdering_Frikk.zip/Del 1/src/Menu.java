import java.util.ArrayList;
import java.util.Scanner;

/**
 * The Menu class. It handles all interaction with the user.
 *
 * @author Frikk O. Larsen
 * @version 1.0.0
 */
public class Menu {
  private final Scanner in = new Scanner(System.in);
  private final ItemRegistry registry = new ItemRegistry("Smarthus AS");

  /**
   * The main method runs when the file is started.
   *
   * @param args List of arguments
   */
  public static void main(String[] args) {
    // Print a one time warning about the FuzzyWuzzy dependency
    System.out.println("""
            
            [WARNING] To search through items in the registry, this program uses the
            FuzzyWuzzy library, which can be downloaded from https://github.com/xdrop/fuzzywuzzy.
            If this is not added as a project dependency, parts of the search feature
            will NOT work as intended. There is a fallback feature enabling description
            search, but this is not as precise or user friendly.
            """);

    // Instantiate a menu class
    Menu menu = new Menu();

    // Create some sample items
    menu.registry.addItem("1A", "Tredør av bjørk", 700, "Egger",
            20.0f, 2.5f, 1, "grå", 23, 3, 0f);

    boolean doLoop = true;
    while (doLoop) {

      // Print all available actions
      int menuChoice = menu.printOptions();

      // Parse the returned integer into an enum
      MenuConstants enumEquivalent = MenuConstants.fromInteger(menuChoice);

      // Perform requested action
      switch (enumEquivalent) {
        case PRINT_ALL -> menu.printAllItems();
        case SEARCH_ITEM -> menu.searchItem();
        case ADD_ITEM -> menu.addItem();
        case INCREASE_ITEM_STOCK -> {
          int increasedStock = menu.increaseItemStock();
          System.out.println("There are now " + increasedStock + " of this item in the registry");
        }
        case DECREASE_ITEM_STOCK -> {
          int decreasedStock = menu.decreaseItemStock();
          System.out.println("There are now " + decreasedStock + " of this item in the registry");
        }
        case DELETE_ITEM -> {
          boolean result = menu.removeItemFromStock();
          if (result) {
            System.out.println("\n The item has been removed from the registry!");
          } else {
            System.out.println("Could not remove the item. Please try again by selecting"
                    + " 'Remove item from stock'.");
          }
        }
        case CHANGE_ITEM_PRICE -> menu.changeItemPrice();
        case CHANGE_ITEM_DISCOUNT -> menu.changeItemDiscount();
        case CHANGE_ITEM_DESCRIPTION -> menu.changeItemDescription();
        case EXIT -> doLoop = false;
      }
    }
  }


  /**
   * Searches for an Item with either a given description, or item number.
   */
  private void searchItem() {
    boolean doLoop = true;
    while (doLoop) {

      System.out.println("""
              **What do you want to search for?**
              1. Item number
              2. Description
              3. Go back""");

      int input = in.nextInt();
      System.out.println(input);

      // Define a dummy primitive, because the Java Scanner API is buggy
      String dummy;

      switch (input) {
        case 1 -> {
          System.out.println("\n Please enter an Item number");
          dummy = in.nextLine();
          String number = in.nextLine();
          Item numberItem = registry.findItem(number, null);
          if (numberItem == null) {
            System.out.println("No items were found.");
          } else {
            System.out.println(numberItem);
          }
        }
        case 2 -> {
          System.out.println("\n Please enter an Item description");
          dummy = in.nextLine();
          String description = in.nextLine();
          Item descriptionItem = registry.findItem(null, description);
          if (descriptionItem == null) {
            System.out.println("\nNo items matching this description were found.\n");
          } else {
            System.out.println(descriptionItem + "\n");
          }
        }
        case 3 -> doLoop = false;
        default -> System.out.println("Sorry, that's not a valid option. Please input a number"
                + " between 1 and 2");
      }
    }
  }

  /**
   * Adds an item to the item registry.
   */
  private void addItem() {
    System.out.println("\n Input an Item number");
    String dummy = in.nextLine();
    String number = in.nextLine();

    System.out.println("\n Input an Item description (Text)");
    String description = in.nextLine();

    System.out.println("\n Input an Item price (Round number)");
    int price = in.nextInt();

    System.out.println("\n Input an Item brand");
    String dummyA = in.nextLine();
    String brand = in.nextLine();

    System.out.println("\n Input an Item weight (kg)");
    float weight = in.nextFloat();

    System.out.println("\n Input an Item length (Meters)");
    float length = in.nextFloat();

    System.out.println("\n Input an Item height (Meters)");
    float height = in.nextFloat();

    System.out.println("\n Input an Item color (Text)");
    String dummyB = in.nextLine();
    String color = in.nextLine();

    System.out.println("\n Input the Item amount (Whole number)");
    int stock = in.nextInt();

    System.out.println("\n Input the Item category (Whole number between 1-4)");
    int category = in.nextInt();

    System.out.println("\n Input the discount percentage. 0 if no discount.");
    float discount = in.nextFloat();

    try {
      Item item = registry.addItem(number, description, price, brand,
              weight, length, height, color, stock, category, discount);

      // Check if the item actually was added to the registry
      if (item == null) {
        System.out.println("\n The item wasn't added to the registry, because another item"
                + " with the same item number already exists");
        return;
      }
    } catch (IllegalArgumentException e) {
      System.out.println("\n Could not create Item for the following reason:");
      System.out.println(e.getMessage());
      return;
    }

    System.out.println("\nThe item has successfully been added to the registry!\n");
  }

  /**
   * Prints all options, and returns the selected option.
   *
   * @return The option selected by the user
   */
  private int printOptions() {
    while (true) {
      System.out.println("\n**Welcome! What do you want to do?**");
      System.out.println("""
              1. View all items
              2. Search for item
              3. Add new item
              4. Increase item stock
              5. Decrease item stock
              6. Remove item from stock
              7. Change item price
              8. Change item discount
              9. Change item description
              10. Exit
              """);
      int input = in.nextInt();
      if (input > 10 || input < 1) {
        System.out.println("Please enter a valid option");
        continue;
      }

      return input;
    }

  }

  /**
   * Is called when the user wishes to print all items to the console.
   */
  private void printAllItems() {
    final ArrayList<Item> items = registry.getAllItems();

    if (items.size() == 0) {
      System.out.println("No items have been registered.\n");
      return;
    }

    for (Item item : items) {
      System.out.println(item);
    }
  }

  /**
   * Increases item stock for a certain item by
   * a given amount.
   *
   * @return The updated stock number for that item
   */
  private int increaseItemStock() {
    while (true) {
      System.out.println("\n What item would you like to target? (Item number)");
      String dummy = in.nextLine();
      String number = in.nextLine();

      if (number.trim().length() == 0) {
        System.out.println("\n Please specify a valid Item number.");
        continue;
      }

      System.out.println("\n How many items would you like to add?");
      int amount = in.nextInt();

      if (amount < 1) {
        System.out.println("Cannot add less than 1 to the stock.");
        continue;
      }

      return registry.changeItemStock(amount, number);
    }
  }

  /**
   * Decreases item stock for a certain item by
   * a given amount.
   *
   * @return The updated stock number for that item
   */
  private int decreaseItemStock() {
    while (true) {
      String number = this.getItemNumber();

      if (number == null) {
        System.out.println("\n Please specify a valid Item number.");
        continue;
      }

      System.out.println("\n How many items would you like to remove?");
      int amount = in.nextInt();

      if (amount < 1) {
        System.out.println("Cannot remove less than 1 from the stock.");
        continue;
      }

      return registry.changeItemStock(-amount, number);
    }
  }

  /**
   * Removes a given item from the registry.
   *
   * @return True if successful, false if not.
   */
  private boolean removeItemFromStock() {
    String number = this.getItemNumber();
    if (number == null) {
      System.out.println("\n Please specify a valid Item number.");
      return false;
    }

    // Remove the item and return the result
    return registry.deleteItem(number);
  }

  private String getItemNumber() {
    System.out.println("\n What Item would you like to target?");
    String dummy = in.nextLine();
    String number = in.nextLine();


    if (number.trim().length() == 0) {
      return null;
    }

    return number;
  }

  /**
   * Changes the item price to a new, given price
   */
  private void changeItemPrice() {
    while (true) {
      String number = this.getItemNumber();

      if (number == null) {
        System.out.println("\n Please specify a valid Item number.");
        continue;
      }

      // Break out of the loop if the user wishes to do so.
      if (number.toLowerCase().equals("exit")) {
        return;
      }

      // Get the old item price
      Item item = registry.findItem(number, null);

      // Check if the item exists, if not, ask the user to try again
      if (item == null) {
        System.out.println("\n This item could not be found! Please try again."
                + " Type 'exit' to cancel.");
        continue;
      }

      System.out.println("\n Please specify a new price for this item"
              + " (old price: " + item.getPrice() + ")");
      int price = in.nextInt();

      registry.changeItemPrice(price, number);

      // Print the item out
      System.out.println("\n Updated item:");
      System.out.println(registry.findItem(number, null));

      return;
    }
  }

  private void changeItemDiscount() {
    while (true) {
      String number = this.getItemNumber();

      if (number == null) {
        System.out.println("\n Please specify a valid Item number.");
        continue;
      }

      // Break out of the loop if the user wishes to do so.
      if (number.toLowerCase().equals("exit")) {
        return;
      }

      // Get the old item price
      Item item = registry.findItem(number, null);

      // Check if the item exists, if not, ask the user to try again
      if (item == null) {
        System.out.println("\n This item could not be found! Please try again."
                + " Type 'exit' to cancel.");
        continue;
      }

      System.out.println("\n Please specify a new discount for this item"
              + " (old discount: " + item.getDiscountPercentage() + "%)");
      float discount = in.nextFloat();

      System.out.println(discount);

      registry.changeItemDiscount(discount, number);

      // Print the item out
      System.out.println("\n Updated item:");
      System.out.println(registry.findItem(number, null));

      return;
    }
  }

  private void changeItemDescription() {
    while (true) {
      String number = this.getItemNumber();

      if (number == null) {
        System.out.println("\n Please specify a valid Item number.");
        continue;
      }

      // Break out of the loop if the user wishes to do so.
      if (number.toLowerCase().equals("exit")) {
        return;
      }

      // Get the old item price
      Item item = registry.findItem(number, null);

      // Check if the item exists, if not, ask the user to try again
      if (item == null) {
        System.out.println("\n This item could not be found! Please try again."
                + " Type 'exit' to cancel.");
        continue;
      }

      System.out.println("\n Please specify a new description for this item"
              + " (old: " + item.getDescription() + ")");
      String description = in.nextLine();

      registry.changeItemDescription(description, number);

      // Print the item out
      System.out.println("\n Updated item:");
      System.out.println(registry.findItem(number, null));

      return;
    }
  }
}
