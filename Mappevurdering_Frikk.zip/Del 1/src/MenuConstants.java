/**
 * These are the predefined menu choice constants.
 *
 * @author Frikk O. Larsen
 * @version 1.0.0
 */
public enum MenuConstants {
  PRINT_ALL,
  SEARCH_ITEM,
  ADD_ITEM,
  INCREASE_ITEM_STOCK,
  DECREASE_ITEM_STOCK,
  DELETE_ITEM,
  CHANGE_ITEM_PRICE,
  CHANGE_ITEM_DISCOUNT,
  CHANGE_ITEM_DESCRIPTION,
  EXIT;

  /**
   * Transform a given integer into an enum.
   *
   * @param x The integer to transform
   * @return An enum
   */
  public static MenuConstants fromInteger(int x) {
    try {
      return MenuConstants.values()[x - 1];
    } catch (Exception e) {
      System.out.println(e);
      return MenuConstants.PRINT_ALL;
    }
  }
}